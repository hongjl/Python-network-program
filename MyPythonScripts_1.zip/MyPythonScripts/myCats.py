cats = [{'desc': 'chubby', 'name': 'zophie'}, {'desc': 'fluffy', 'name': 'pooka'}]
